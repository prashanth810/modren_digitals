import { s as require_jsx_runtime } from "../_libs/@react-three/drei+[...].mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { E as Check, j as ArrowRight } from "../_libs/lucide-react.mjs";
import { n as PageHero, r as Reveal, t as CTASection } from "./primitives-Br5DAkAp.mjs";
import { o as services, s as technologies } from "./site-sNGuuuSj.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/services-pd2uB_L8.js
var import_jsx_runtime = require_jsx_runtime();
function ServicesPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHero, {
			label: "Capabilities",
			index: "01—05",
			title: "Services that turn ideas into digital products.",
			copy: "From focused landing pages to complete platforms, I help businesses build modern, scalable, high-performing experiences."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "section pt-0",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "shell border-t border-border",
				children: services.map((service) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
					className: "service-detail",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "service-detail__lead",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: service.number }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(service.icon, {}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: service.title }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: service.description })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { children: service.items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {}), item] }, item)) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "tag-row self-start",
							children: service.tags.map((tag) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: tag }, tag))
						})
					]
				}, service.number))
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "section overflow-hidden border-y border-border bg-surface",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "shell",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "eyebrow",
						children: "Technology toolkit"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "section-title mt-5 max-w-3xl",
						children: "The right technology, selected for the job."
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "tech-marquee mt-14",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: [...technologies, ...technologies].map((tech, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [tech, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { children: "✦" })] }, `${tech}-${i}`)) })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "shell mt-12",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/contact",
						className: "text-link",
						children: ["Discuss your technology needs ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {})]
					})
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CTASection, {})
	] });
}
//#endregion
export { ServicesPage as component };
