import { c as createServerFn, i as TSS_SERVER_FUNCTION } from "./createServerFn-CIHAFgYl.mjs";
import { n as objectType, r as stringType, t as enumType } from "../_libs/zod.mjs";
import processModule from "node:process";
//#region node_modules/.nitro/vite/services/ssr/assets/contact.functions-CX-iSawP.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var contactSchema = objectType({
	name: stringType().trim().min(2, "Please enter your name.").max(100),
	email: stringType().trim().email("Please enter a valid email address.").max(255),
	phone: stringType().trim().max(30).optional().default(""),
	company: stringType().trim().max(120).optional().default(""),
	projectType: enumType([
		"Website",
		"E-commerce",
		"Web Application",
		"UI/UX",
		"Full-Stack Application",
		"Business Platform",
		"Other"
	], { message: "Please select a project type." }),
	budget: enumType([
		"Under ₹25,000",
		"₹25,000 – ₹50,000",
		"₹50,000 – ₹1,00,000",
		"₹1,00,000+"
	], { message: "Please select a budget range." }),
	message: stringType().trim().min(10, "Please share a little more about your project.").max(3e3)
});
var escapeHtml = (value) => value.replace(/[&<>'"]/g, (character) => {
	return {
		"&": "&amp;",
		"<": "&lt;",
		">": "&gt;",
		"'": "&#39;",
		"\"": "&quot;"
	}[character] ?? character;
});
var sendContactEnquiry_createServerFn_handler = createServerRpc({
	id: "b700adb6722fed03d850210934c4f5127c0c3bcd0039e8db923854cd98e47e0d",
	name: "sendContactEnquiry",
	filename: "src/lib/contact.functions.ts"
}, (opts) => sendContactEnquiry.__executeServer(opts));
var sendContactEnquiry = createServerFn({ method: "POST" }).inputValidator((input) => contactSchema.parse(input)).handler(sendContactEnquiry_createServerFn_handler, async ({ data }) => {
	const lovableApiKey = processModule.env["LOVABLE_API_KEY"];
	const resendApiKey = processModule.env["RESEND_API_KEY"];
	if (!lovableApiKey || !resendApiKey) throw new Error("Email delivery is not configured.");
	const safe = Object.fromEntries(Object.entries(data).map(([key, value]) => [key, escapeHtml(value)]));
	const response = await fetch("https://connector-gateway.lovable.dev/resend/emails", {
		method: "POST",
		headers: {
			Authorization: `Bearer ${lovableApiKey}`,
			"X-Connection-Api-Key": resendApiKey,
			"Content-Type": "application/json"
		},
		body: JSON.stringify({
			from: "Northstar Digital <onboarding@resend.dev>",
			to: ["supportweb329@gmail.com"],
			reply_to: data.email,
			subject: `New ${data.projectType} enquiry from ${data.name}`,
			html: `
          <h1>New project enquiry</h1>
          <p><strong>Name:</strong> ${safe.name}</p>
          <p><strong>Email:</strong> ${safe.email}</p>
          <p><strong>Phone:</strong> ${safe.phone || "Not provided"}</p>
          <p><strong>Company:</strong> ${safe.company || "Not provided"}</p>
          <p><strong>Project type:</strong> ${safe.projectType}</p>
          <p><strong>Budget:</strong> ${safe.budget}</p>
          <p><strong>Message:</strong></p>
          <p>${safe.message.replace(/\n/g, "<br />")}</p>
        `
		})
	});
	if (!response.ok) {
		const errorBody = await response.text();
		console.error(`Resend request failed [${response.status}]: ${errorBody}`);
		throw new Error("Your enquiry could not be sent. Please try again.");
	}
	return { sent: true };
});
//#endregion
export { sendContactEnquiry_createServerFn_handler };
