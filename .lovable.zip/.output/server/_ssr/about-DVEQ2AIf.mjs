import { s as require_jsx_runtime } from "../_libs/@react-three/drei+[...].mjs";
import { D as ChartColumn, a as Sprout, b as Gem, x as Gauge } from "../_libs/lucide-react.mjs";
import { i as SectionHeading, n as PageHero, r as Reveal, t as CTASection } from "./primitives-Br5DAkAp.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/about-DVEQ2AIf.js
var import_jsx_runtime = require_jsx_runtime();
var values = [
	[
		"01",
		"Quality",
		"Attention to detail from the first sketch to the final release.",
		Gem
	],
	[
		"02",
		"Simplicity",
		"Complex systems made clear, useful, and comfortable to navigate.",
		ChartColumn
	],
	[
		"03",
		"Performance",
		"Fast, stable experiences engineered for the real world.",
		Gauge
	],
	[
		"04",
		"Growth",
		"Technology designed to evolve with the business around it.",
		Sprout
	]
];
function AboutPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHero, {
			label: "The practice",
			index: "2024—NOW",
			title: "Technology, design & business — working together.",
			copy: "Northstar is an independent digital practice focused on modern products that perform beautifully and make commercial sense."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "section pt-0",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "shell grid gap-14 border-t border-border pt-16 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "portrait-art",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "portrait-grid" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "portrait-mark",
							children: "N/S"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
							"Independent practice",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
							"India / Worldwide"
						] })
					]
				}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "eyebrow",
						children: "An integrated approach"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-5 text-3xl font-semibold leading-tight lg:text-5xl",
						children: "Clear design is only powerful when the engineering and business logic support it."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 space-y-6 text-base leading-8 text-muted-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "I create digital products by treating interface, technology, and strategy as one connected system—not separate deliverables." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "The result is work that feels distinctive without becoming distracting, performs under real constraints, and gives teams a solid foundation for what comes next." })]
					})
				] })]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "section border-y border-border bg-surface",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "shell",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
					label: "Trajectory",
					title: "Always moving forward"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "timeline mt-14",
					children: [
						["2024", "Started building professional web experiences."],
						["2025", "Expanded into full-stack systems and business applications."],
						["2026", "Building scalable products and stronger digital foundations for ambitious businesses."]
					].map(([year, text]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
						className: "timeline-item",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: year }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: text })
						]
					}, year))
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "section",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "shell",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
					label: "Principles",
					title: "Standards that shape every project"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-14 grid gap-px border border-border bg-border md:grid-cols-2",
					children: values.map(([n, title, text, Icon]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
						className: "value-card",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: n }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: title }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: text })
						]
					}, title))
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CTASection, {})
	] });
}
//#endregion
export { AboutPage as component };
