import { i as __toESM } from "../_runtime.mjs";
import { v as MathUtils } from "../_libs/@monogrid/gainmap-js+[...].mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { a as useFrame, i as Canvas, n as Environment, r as Float, s as require_jsx_runtime, t as Lightformer } from "../_libs/@react-three/drei+[...].mjs";
import { t as Button } from "./button-B2sSz6b5.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as motion } from "../_libs/motion.mjs";
import { E as Check, M as ArrowDown, j as ArrowRight } from "../_libs/lucide-react.mjs";
import { i as SectionHeading, r as Reveal, t as CTASection } from "./primitives-Br5DAkAp.mjs";
import { a as projects, i as process, o as services, t as benefits } from "./site-sNGuuuSj.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BK6NwKIY.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Core() {
	const group = (0, import_react.useRef)(null);
	const nodes = (0, import_react.useMemo)(() => Array.from({ length: 18 }, (_, i) => {
		const phi = Math.acos(-1 + 2 * i / 18);
		const theta = Math.sqrt(18 * Math.PI) * phi;
		return [
			Math.cos(theta) * Math.sin(phi) * 2.05,
			Math.sin(theta) * Math.sin(phi) * 2.05,
			Math.cos(phi) * 2.05
		];
	}), []);
	useFrame((state, rawDelta) => {
		if (!group.current) return;
		const delta = Math.min(rawDelta, .05);
		group.current.rotation.y += delta * .12;
		group.current.rotation.x = MathUtils.lerp(group.current.rotation.x, state.pointer.y * .15, 1 - Math.exp(-3 * delta));
		group.current.rotation.z = MathUtils.lerp(group.current.rotation.z, -state.pointer.x * .12, 1 - Math.exp(-3 * delta));
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Float, {
		speed: 1.1,
		rotationIntensity: .18,
		floatIntensity: .3,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", {
			ref: group,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("icosahedronGeometry", { args: [1.35, 2] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshPhysicalMaterial", {
					color: "#5dd9f5",
					metalness: .78,
					roughness: .18,
					transmission: .18,
					wireframe: true
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
					rotation: [
						.5,
						.25,
						.4
					],
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("torusGeometry", { args: [
						1.8,
						.025,
						10,
						120
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshBasicMaterial", {
						color: "#7be7ff",
						transparent: true,
						opacity: .48
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
					rotation: [
						1.2,
						.4,
						-.5
					],
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("torusGeometry", { args: [
						2.18,
						.012,
						8,
						120
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshBasicMaterial", {
						color: "#f3a55b",
						transparent: true,
						opacity: .45
					})]
				}),
				nodes.map((position, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
					position,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("sphereGeometry", { args: [
						i % 5 === 0 ? .085 : .045,
						12,
						12
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshStandardMaterial", {
						color: i % 5 === 0 ? "#f3a55b" : "#b9f3ff",
						emissive: i % 5 === 0 ? "#f3a55b" : "#5dd9f5",
						emissiveIntensity: 1.8
					})]
				}, i))
			]
		})
	});
}
function Scene() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ambientLight", { intensity: .55 }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pointLight", {
			position: [
				3,
				3,
				5
			],
			intensity: 22,
			color: "#79e5ff"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pointLight", {
			position: [
				-4,
				-2,
				2
			],
			intensity: 14,
			color: "#f0a561"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Core, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Environment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lightformer, {
			intensity: 2,
			position: [
				0,
				5,
				2
			],
			scale: [
				10,
				10,
				1
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lightformer, {
			intensity: 1.2,
			color: "#74dff6",
			position: [
				-5,
				1,
				-1
			],
			"rotation-y": Math.PI / 2,
			scale: [
				8,
				2,
				1
			]
		})] })
	] });
}
function HeroScene() {
	const [mounted, setMounted] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => setMounted(true), []);
	if (!mounted) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "scene-fallback",
		"aria-hidden": true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Canvas, {
		dpr: [1, 1.5],
		camera: {
			position: [
				0,
				0,
				7
			],
			fov: 42
		},
		gl: {
			antialias: true,
			alpha: true
		},
		fallback: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "scene-fallback" }),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scene, {})
	});
}
function HomePage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "hero-section",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "hero-grid" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "shell relative z-10 grid min-h-[880px] items-center gap-8 pb-20 pt-28 lg:min-h-[760px] lg:grid-cols-[1.08fr_.92fr] lg:pt-24",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "pt-10 lg:pt-0",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.p, {
								initial: {
									opacity: 0,
									y: 12
								},
								animate: {
									opacity: 1,
									y: 0
								},
								className: "eyebrow",
								children: [
									"Creative digital solutions ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "status-dot" }),
									" Available for select projects"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.h1, {
								initial: {
									opacity: 0,
									y: 24
								},
								animate: {
									opacity: 1,
									y: 0
								},
								transition: {
									delay: .08,
									duration: .7
								},
								className: "hero-title mt-7",
								children: [
									"Digital experiences",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
									"built to ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "move" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
									"business forward."
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.p, {
								initial: {
									opacity: 0,
									y: 18
								},
								animate: {
									opacity: 1,
									y: 0
								},
								transition: { delay: .18 },
								className: "mt-7 max-w-xl text-base leading-8 text-muted-foreground lg:text-lg",
								children: "I combine exceptional interface design, robust technology, and business-focused thinking to create products people trust and enjoy using."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
								initial: {
									opacity: 0,
									y: 18
								},
								animate: {
									opacity: 1,
									y: 0
								},
								transition: { delay: .26 },
								className: "mt-9 flex flex-wrap gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									asChild: true,
									variant: "signal",
									size: "xl",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
										to: "/contact",
										children: ["Start a project ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {})]
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									asChild: true,
									variant: "outline",
									size: "xl",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/services",
										children: "View services"
									})
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
						initial: {
							opacity: 0,
							scale: .9
						},
						animate: {
							opacity: 1,
							scale: 1
						},
						transition: {
							delay: .15,
							duration: .9
						},
						className: "hero-canvas",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeroScene, {}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "canvas-label top-5 left-5",
								children: "DIGITAL CORE / 01"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "canvas-label right-5 bottom-5",
								children: "POINTER REACTIVE"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "scroll-cue",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowDown, {}), " Scroll to explore"]
					})
				]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "stats-band",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "shell grid sm:grid-cols-2 lg:grid-cols-4",
				children: [
					["2+", "Years experience"],
					["20+", "Projects delivered"],
					["10+", "Technologies"],
					["100%", "Client focus"]
				].map(([n, l]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "stat",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: n }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: l })]
				}, l))
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "section",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "shell",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
						label: "Capabilities / 01",
						title: "What I can build for you",
						copy: "From first principles to final release, each engagement connects clear thinking with meticulous execution."
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-14 grid gap-px border border-border bg-border md:grid-cols-2",
						children: services.slice(0, 4).map((service) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
							className: "service-card",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-start justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "service-number",
										children: service.number
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(service.icon, {})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: service.title }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: service.description }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "tag-row",
									children: service.tags.map((tag) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: tag }, tag))
								})
							]
						}, service.title))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/services",
						className: "text-link mt-9",
						children: ["Explore all services ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {})]
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "section border-y border-border bg-surface",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "shell",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
					label: "Selected work / 02",
					title: "Proof, not promises",
					copy: "Representative product directions ready to be replaced with your real case studies."
				}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-14 grid gap-6 lg:grid-cols-12",
					children: projects.map((project, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
						className: `project ${i === 0 ? "lg:col-span-7" : "lg:col-span-5"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: `project-visual project-visual--${project.tone}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "project-window",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "project-ui" })
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "project-index",
								children: project.index
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "pt-6",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "eyebrow",
									children: project.category
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "mt-3 text-2xl font-semibold",
									children: project.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 text-sm leading-7 text-muted-foreground",
									children: project.description
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "tag-row mt-5",
									children: project.stack.map((tag) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: tag }, tag))
								})
							]
						})]
					}, project.name))
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "section",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "shell",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
					label: "Method / 03",
					title: "How I work"
				}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "process-line mt-14",
					children: process.map((step) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
						className: "process-step",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: step.number }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(step.icon, {}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: step.title }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: step.text })
						]
					}, step.number))
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "section border-t border-border",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "shell grid gap-12 lg:grid-cols-[.8fr_1.2fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
					label: "The difference / 04",
					title: "Built with intent. Delivered with care.",
					copy: "Good digital work is not decoration. It clarifies, earns confidence, and moves the business."
				}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-px border border-border bg-border sm:grid-cols-2",
					children: benefits.map(([title, text, Icon]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
						className: "benefit",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: title }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: text }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {})
						]
					}, title))
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CTASection, {})
	] });
}
//#endregion
export { HomePage as component };
