import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@react-three/drei+[...].mjs";
import { t as Button } from "./button-B2sSz6b5.mjs";
import { D as isRedirect, _ as useRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { T as CircleAlert, _ as Linkedin, g as LoaderCircle, h as Mail, m as MapPin, s as Send, u as Phone, w as CircleCheck, y as Github } from "../_libs/lucide-react.mjs";
import { n as PageHero, r as Reveal } from "./primitives-Br5DAkAp.mjs";
import { t as getServerFnById } from "../__23tanstack-start-server-fn-resolver-Bw-0jYZ3.mjs";
import { c as createServerFn, i as TSS_SERVER_FUNCTION } from "./createServerFn-CIHAFgYl.mjs";
import { n as brand } from "./site-sNGuuuSj.mjs";
import { n as objectType, r as stringType, t as enumType } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/contact-CoizvNwY.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function useServerFn(serverFn) {
	const router = useRouter();
	return import_react.useCallback(async (...args) => {
		try {
			const res = await serverFn(...args);
			if (isRedirect(res)) throw res;
			return res;
		} catch (err) {
			if (isRedirect(err)) {
				err.options._fromLocation = router.stores.location.get();
				return router.navigate(router.resolveRedirect(err).options);
			}
			throw err;
		}
	}, [router, serverFn]);
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var contactSchema = objectType({
	name: stringType().trim().min(2, "Please enter your name.").max(100),
	email: stringType().trim().email("Please enter a valid email address.").max(255),
	phone: stringType().trim().max(30).optional().default(""),
	company: stringType().trim().max(120).optional().default(""),
	projectType: enumType([
		"Website",
		"E-commerce",
		"Web Application",
		"UI/UX",
		"Full-Stack Application",
		"Business Platform",
		"Other"
	], { message: "Please select a project type." }),
	budget: enumType([
		"Under ₹25,000",
		"₹25,000 – ₹50,000",
		"₹50,000 – ₹1,00,000",
		"₹1,00,000+"
	], { message: "Please select a budget range." }),
	message: stringType().trim().min(10, "Please share a little more about your project.").max(3e3)
});
var sendContactEnquiry = createServerFn({ method: "POST" }).inputValidator((input) => contactSchema.parse(input)).handler(createSsrRpc("b700adb6722fed03d850210934c4f5127c0c3bcd0039e8db923854cd98e47e0d"));
function ContactForm() {
	const [status, setStatus] = (0, import_react.useState)("idle");
	const [error, setError] = (0, import_react.useState)("");
	const sendEnquiry = useServerFn(sendContactEnquiry);
	const submit = async (event) => {
		event.preventDefault();
		setError("");
		const form = event.currentTarget;
		const raw = Object.fromEntries(new FormData(form));
		const result = contactSchema.safeParse(raw);
		if (!result.success) {
			setError(result.error.issues[0]?.message ?? "Please check your details and try again.");
			setStatus("error");
			return;
		}
		setStatus("loading");
		try {
			await sendEnquiry({ data: result.data });
			form.reset();
			setStatus("success");
		} catch {
			setError("Your enquiry could not be sent. Please try again in a moment.");
			setStatus("error");
		}
	};
	if (status === "success") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "form-success",
		role: "status",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Enquiry received." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Thanks for reaching out. Your message has been sent to Northstar Digital." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "outline",
				onClick: () => setStatus("idle"),
				children: "Send another"
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit: submit,
		className: "contact-form",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "field-grid",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: ["Name", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					name: "name",
					required: true,
					placeholder: "Your name"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: ["Email", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					name: "email",
					type: "email",
					required: true,
					placeholder: "you@company.com"
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "field-grid",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: ["Phone", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					name: "phone",
					type: "tel",
					placeholder: "Your phone number"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: ["Company / Business", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					name: "company",
					placeholder: "Company name"
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "field-grid",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: ["Project type", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					name: "projectType",
					required: true,
					defaultValue: "",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "",
						disabled: true,
						children: "Select a project"
					}), [
						"Website",
						"E-commerce",
						"Web Application",
						"UI/UX",
						"Full-Stack Application",
						"Business Platform",
						"Other"
					].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: item }, item))]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: ["Budget range", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					name: "budget",
					required: true,
					defaultValue: "",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "",
						disabled: true,
						children: "Select a range"
					}), [
						"Under ₹25,000",
						"₹25,000 – ₹50,000",
						"₹50,000 – ₹1,00,000",
						"₹1,00,000+"
					].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: item }, item))]
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: ["Message", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
				name: "message",
				required: true,
				minLength: 10,
				maxLength: 3e3,
				rows: 6,
				placeholder: "Tell me about the challenge, timeline, and what success looks like."
			})] }),
			status === "error" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "form-error",
				role: "alert",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, {}), error]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "submit",
				variant: "signal",
				size: "xl",
				disabled: status === "loading",
				children: status === "loading" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin" }), "Sending…"] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: ["Send enquiry ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, {})] })
			})
		]
	});
}
function ContactPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHero, {
		label: "Start a project",
		index: "OPEN / 2026",
		title: "Let’s build something great together.",
		copy: "Have a project, idea, or business problem you’d like to discuss? Share the essentials and let’s start a focused conversation."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "section pt-0",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "shell grid gap-12 border-t border-border pt-16 lg:grid-cols-[.72fr_1.28fr]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "eyebrow",
					children: "Direct contact"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "contact-list",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: `mailto:${brand.email}`,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, {}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Email" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: brand.email })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: `tel:${brand.phone}`,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, {}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Phone" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: brand.phone })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, {}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Location" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: brand.location })
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: brand.linkedin,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Linkedin, {}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "LinkedIn" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "[LINKEDIN URL]" })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: brand.github,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Github, {}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "GitHub" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "[GITHUB URL]" })
							]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-8 max-w-sm text-sm leading-7 text-muted-foreground",
					children: "Your details stay private and are only used to discuss your enquiry."
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "form-panel",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "eyebrow",
						children: "Project enquiry / 01"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-4 text-3xl font-semibold",
						children: "Tell me what you’re building."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContactForm, {})
				]
			}) })]
		})
	})] });
}
//#endregion
export { ContactPage as component };
