//#region node_modules/.nitro/vite/services/ssr/assets/__23tanstack-start-server-fn-resolver-Bw-0jYZ3.js
var manifest = { "b700adb6722fed03d850210934c4f5127c0c3bcd0039e8db923854cd98e47e0d": {
	functionName: "sendContactEnquiry_createServerFn_handler",
	importer: () => import("./_ssr/contact.functions-CX-iSawP.mjs")
} };
async function getServerFnById(id, access) {
	const serverFnInfo = manifest[id];
	if (!serverFnInfo) throw new Error("Server function info not found for " + id);
	const fnModule = serverFnInfo.module ?? await serverFnInfo.importer();
	if (!fnModule) throw new Error("Server function module not resolved for " + id);
	const action = fnModule[serverFnInfo.functionName];
	if (!action) throw new Error("Server function module export not resolved for serverFn ID: " + id);
	return action;
}
//#endregion
export { getServerFnById as t };
