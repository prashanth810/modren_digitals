//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-pzgXfghx.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "D:/Lovable/PROJECTS/Personal brand website/brand_web/src/routes/__root.tsx",
		children: [
			"/",
			"/about",
			"/contact",
			"/services"
		],
		preloads: ["/assets/index-BXiyMVd8.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BXiyMVd8.js"
		} }]
	},
	"/": {
		filePath: "D:/Lovable/PROJECTS/Personal brand website/brand_web/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-Bv3JszYK.js",
			"/assets/primitives-C2xiZvOF.js",
			"/assets/check-lurMxneK.js"
		]
	},
	"/about": {
		filePath: "D:/Lovable/PROJECTS/Personal brand website/brand_web/src/routes/about.tsx",
		children: void 0,
		preloads: ["/assets/about-DUm4m7nR.js", "/assets/primitives-C2xiZvOF.js"]
	},
	"/contact": {
		filePath: "D:/Lovable/PROJECTS/Personal brand website/brand_web/src/routes/contact.tsx",
		children: void 0,
		preloads: ["/assets/contact-BH4G8NbG.js", "/assets/primitives-C2xiZvOF.js"]
	},
	"/services": {
		filePath: "D:/Lovable/PROJECTS/Personal brand website/brand_web/src/routes/services.tsx",
		children: void 0,
		preloads: [
			"/assets/services-BSUD3zR8.js",
			"/assets/primitives-C2xiZvOF.js",
			"/assets/check-lurMxneK.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
