import {
  Braces,
  Boxes,
  DraftingCompass,
  Gauge,
  Globe2,
  Layers3,
  PanelsTopLeft,
  Rocket,
  Search,
  Sparkles,
  Waypoints,
  Workflow,
} from "lucide-react";

export const brand = {
  name: "NORTHSTAR / DIGITAL",
  shortName: "",
  person: "[YOUR NAME]",
  email: "[EMAIL]",
  phone: "[PHONE]",
  location: "[LOCATION]",
  linkedin: "#",
  github: "#",
  instagram: "#",
};

export const navItems = [
  { label: "Home", to: "/" as const },
  { label: "Services", to: "/services" as const },
  { label: "About", to: "/about" as const },
  { label: "Contact", to: "/contact" as const },
];

export const services = [
  {
    number: "01",
    title: "Web Development",
    icon: Globe2,
    description:
      "Fast, expressive websites engineered to turn attention into measurable business momentum.",
    tags: ["React", "Tailwind", "Node.js"],
    items: [
      "Business websites",
      "Landing pages",
      "Corporate websites",
      "Portfolio websites",
      "E-commerce websites",
      "Responsive web applications",
    ],
  },
  {
    number: "02",
    title: "Frontend Development",
    icon: PanelsTopLeft,
    description:
      "Polished interfaces with thoughtful systems, fluid interactions, and excellent performance.",
    tags: ["TypeScript", "React", "Redux"],
    items: [
      "React applications",
      "Responsive interfaces",
      "Component architecture",
      "API integration",
      "State management",
      "Performance optimization",
    ],
  },
  {
    number: "03",
    title: "Full-Stack Development",
    icon: Braces,
    description:
      "Dependable products spanning intuitive interfaces, secure services, and scalable data layers.",
    tags: ["Node.js", "Express", "MongoDB"],
    items: [
      "REST APIs",
      "Authentication",
      "Database integration",
      "Admin dashboards",
      "Backend services",
      "API architecture",
    ],
  },
  {
    number: "04",
    title: "UI/UX & Product Experience",
    icon: DraftingCompass,
    description:
      "Clear product journeys and distinctive visual systems grounded in real user and business needs.",
    tags: ["UX Strategy", "Design Systems", "Prototyping"],
    items: [
      "Modern interface design",
      "Responsive layouts",
      "User flows",
      "Design systems",
      "Interactive experiences",
      "Conversion-focused pages",
    ],
  },
  {
    number: "05",
    title: "Business Solutions",
    icon: Workflow,
    description:
      "Purpose-built platforms that simplify operations and support the next stage of growth.",
    tags: ["Platforms", "Automation", "Dashboards"],
    items: [
      "Admin panels",
      "CRM-style applications",
      "Service platforms",
      "E-commerce systems",
      "Booking systems",
      "Custom business software",
    ],
  },
];

export const projects = [
  {
    index: "01",
    name: "Orbit Operations",
    category: "Business Management Platform",
    description: "A unified command center for teams, workflows, and operational insight.",
    stack: ["React", "Node.js", "MongoDB"],
    tone: "signal",
  },
  {
    index: "02",
    name: "Aperture Commerce",
    category: "E-commerce Platform",
    description: "A conversion-led retail experience built for speed, clarity, and scale.",
    stack: ["TypeScript", "Payments", "Analytics"],
    tone: "ember",
  },
  {
    index: "03",
    name: "Gather",
    category: "Service Marketplace",
    description: "A trusted two-sided marketplace connecting specialists with ambitious clients.",
    stack: ["React", "APIs", "Cloud"],
    tone: "mint",
  },
];

export const process = [
  {
    number: "01",
    title: "Discover",
    text: "Understand your business, audience, constraints, and the outcome that matters.",
    icon: Search,
  },
  {
    number: "02",
    title: "Design",
    text: "Shape the structure, user journey, and visual system before committing to code.",
    icon: Layers3,
  },
  {
    number: "03",
    title: "Build",
    text: "Engineer the experience with clean systems, tight feedback loops, and rigorous craft.",
    icon: Boxes,
  },
  {
    number: "04",
    title: "Launch",
    text: "Test, optimize, deploy, and support a confident release into the real world.",
    icon: Rocket,
  },
];

export const benefits = [
  ["Business-first", "Every decision connects to a useful outcome.", Waypoints],
  ["Performance", "Fast interaction and thoughtful delivery by default.", Gauge],
  ["Distinctive craft", "A visual language shaped around your brand.", Sparkles],
  ["Built to evolve", "Systems that stay useful as the business grows.", Workflow],
] as const;

export const technologies = [
  "React",
  "TypeScript",
  "JavaScript",
  "HTML",
  "CSS",
  "Tailwind",
  "Node.js",
  "Express",
  "MongoDB",
  "Redux",
  "Git",
  "GitHub",
  "Vercel",
  "Cloudinary",
];
