import * as React from "react";
import { Slot } from "@radix-ui/react-slot";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";
const buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-semibold cursor-pointer transition-all duration-300 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0", { variants: { variant: { default: "bg-primary text-primary-foreground hover:-translate-y-0.5 hover:bg-primary/90", signal: "bg-signal text-signal-foreground shadow-signal hover:-translate-y-0.5 hover:bg-signal-strong", outline: "border border-border bg-transparent text-foreground hover:border-foreground/30 hover:bg-accent", ghost: "text-foreground hover:bg-accent", icon: "border border-border bg-surface/70 text-foreground hover:bg-accent", link: "text-primary underline-offset-4 hover:underline" }, size: { default: "h-11 px-5", sm: "h-9 px-3 text-xs", lg: "h-12 px-7", xl: "h-14 px-7 text-base", icon: "h-11 w-11" } }, defaultVariants: { variant: "default", size: "default" } });
export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement>, VariantProps<typeof buttonVariants> { asChild?: boolean; }
const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(({ className, variant, size, asChild = false, ...props }, ref) => { const Comp = asChild ? Slot : "button"; return <Comp className={cn(buttonVariants({ variant, size, className }))} ref={ref} {...props} />; });
Button.displayName = "Button";
export { Button, buttonVariants };
